# Repository Guidelines

## Project Structure & Module Organization
- `idle_01/ui`: SwiftUI views and app entry (`idle_01App.swift`).
- `idle_01/game`: Simulation engine and models (e.g., `SimulationEngine.swift`, `ScenarioRun.swift`).
- `idle_01/Assets.xcassets`: Images and color assets.
- `idle_01Tests`: Unit tests using XCTest.
- `idle_01UITests`: UI tests using XCUITest.

## Build, Test, and Development Commands
- `open idle_01.xcodeproj`: Open the project in Xcode.
- `xcodebuild -scheme idle_01 -configuration Debug build`: Build Debug locally.
- `xcodebuild test -scheme idle_01 -destination 'platform=iOS Simulator,name=iPhone 15'`: Run unit + UI tests.
- Xcode shortcuts: `Cmd-B` build, `Cmd-U` test, `Cmd-R` run.

## Coding Style & Naming Conventions
- Indentation: 2 spaces; keep lines ≤ ~120 columns.
- Naming: Types `UpperCamelCase`; methods, vars, enum cases `lowerCamelCase`.
- Files: One primary type per file; views in `ui/`, engine/models in `game/`.
- Imports: Keep minimal and sorted. Prefer SwiftUI-first patterns; keep business logic in `game/`, UI state in `ui/`.

## Testing Guidelines
- Frameworks: XCTest (unit) and XCUITest (UI).
- Structure: Mirror modules (e.g., `SimulationEngineTests` for `SimulationEngine`).
- Naming: Functions start with `test` and describe behavior (e.g., `testEngineAdvancesTicks`).
- Run: Use Xcode (`Cmd-U`) or the `xcodebuild test` command above. Favor small, focused tests for pure engine logic.

## Commit & Pull Request Guidelines
- Commits: Imperative, concise subject (e.g., "Add engine tick logic"). Include what/why and tradeoffs; reference issues like `#123`.
- PRs: Clear description, steps to test, linked issues, and screenshots for UI changes. Specify simulator target (iPhone 15, iOS 17).

## Architecture Notes
- SwiftUI-first UI with a lightweight engine layer.
- Views depend on observable models; keep business logic pure and testable in `game/`.
- Prefer small, composable views and pure functions in the engine.

